#include <stdio.h>
#include <stdlib.h>
 
#define N 256 // 1行の最大文字数(バイト数)
#define ROW 16 // 読み込むファイルのデータの行数
#define COL 10 
// 1列目の項目名と2列目以降のデータを格納する配列をメンバにもつ構造体
typedef struct str {
	float f_data[COL];
	int rows;
	int cols;
} data;
float bessj(int n, float x);
void Bessel(float BES[15][10]) {
	FILE *fp; 
	char *fname = "bessel0.csv";
	char line[N];
	float f[COL];
	int i = 0;
 
	data data[15];
 
	fp = fopen(fname, "r"); // ファイルを開く。失敗するとNULLを返す。
	if(fp == NULL) {
		printf("%s file not open!\n", fname);
		
	}
 

	while(fgets(line, N, fp) != NULL) {
		if (i  > 0){

		sscanf(	line, 
				"%f, %f, %f, %f, %f, %f, %f, %f, %f, %f",
			    &f[0], &f[1], &f[2], &f[3], &f[4], &f[5],
			    &f[6], &f[7], &f[8], &f[9]);
 

		float tmp[] = {f[0], f[1], f[2], f[3], f[4], f[5], f[6], f[7], f[8], f[9]};

		for(int j = 0; j  < sizeof(data[i].f_data) / sizeof(data[i].f_data[0]); j++) {
			data[i-1].f_data[j] = tmp[j];
		}
 		}
 		i++;
	}
 	
 	int PRO = 0;
				printf("*--*--*--*--*--*--*--*--*--*--*--*--*--*-- ...\n");
 	for(int k = 0; k < ROW - 1 + PRO; k++){
			for(int l = 0; l < COL; l++){
				if(l < 9){
				printf("%f , ",data[k].f_data[l]);
				} else if (l == 9){
				printf("%f\n",data[k].f_data[l]);
				}
				BES[k][l] = data[k].f_data[l];
			}
		}
				printf("*--*--*--*--*--*--*--*--*--*--*--*--*--*-- ...\n");
				
	fclose(fp); // ファイルを閉じる
   
}

int main(void){

	float BES[15][10] = {0};

	/*
 	int PRO = 0;
 	for(int k = 0; k < ROW - 1 + PRO; k++){
			for(int l = 0; l < COL; l++){
				if(l < 9){
				printf("%f , ",BES[k][l]);
				} else if (l == 9){
				printf("%f\n",BES[k][l]);
				}
			}
		}
	printf("\n");
	*/
	Bessel(BES);
	float be = bessj(3,0.56);
	printf("The Bessel Number is %f\n", be);
	/*
	printf("\n");
 	for(int k = 0; k < ROW - 1 + PRO; k++){
			for(int l = 0; l < COL; l++){
				if(l < 9){
				printf("%f , ",BES[k][l]);
				} else if (l == 9){
				printf("%f\n",BES[k][l]);
				}
			}
		}
	*/
	return 0;
 }
